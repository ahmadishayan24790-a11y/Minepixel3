import MinePixelShop from "../components/MinePixelShop";

export default function Home() {
  return <MinePixelShop />;
}
