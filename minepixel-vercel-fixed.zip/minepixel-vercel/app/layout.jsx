export const metadata = {
  title: "ماین‌پیکسل | فروشگاه آیتم‌های ماین‌کرافت",
  description:
    "ماین‌پیکسل — فروشگاه خرید آیتم‌های ماین‌کرافت: شمشیر، زره، اکسیر و مواد کمیاب با تحویل آنی.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}
