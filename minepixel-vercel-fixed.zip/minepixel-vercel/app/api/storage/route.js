import { Redis } from "@upstash/redis";
import { NextResponse } from "next/server";

// Vercel KV (که این پروژه اولش بر پایه‌ش نوشته شده بود) دیگه وجود نداره.
// جایگزین رسمی‌اش Upstash Redis از طریق Vercel Marketplace هست، که همون
// اسم متغیرهای محیطی قبلی (KV_REST_API_URL و KV_REST_API_TOKEN) رو ست
// می‌کنه تا سازگار بمونه — برای همین fromEnv() بدون تغییری در .env کار می‌کنه.
const kv = Redis.fromEnv();

// همه‌ی کلیدها با این پیشوند ذخیره می‌شن تا اگه همین KV Database رو
// برای چند پروژه استفاده کردی، قاطی نشن.
const PREFIX = "minepixel:";

export async function GET(req) {
  const { searchParams } = new URL(req.url);

  // حالت لیست کلیدها: /api/storage?list=1&prefix=...
  if (searchParams.get("list")) {
    const prefix = searchParams.get("prefix") || "";
    const rawKeys = await kv.keys(`${PREFIX}${prefix}*`);
    const keys = rawKeys.map((k) => k.slice(PREFIX.length));
    return NextResponse.json({ keys, prefix });
  }

  // حالت خواندن یک کلید: /api/storage?key=...
  const key = searchParams.get("key");
  if (!key) {
    return NextResponse.json({ error: "پارامتر key لازمه" }, { status: 400 });
  }
  const value = await kv.get(`${PREFIX}${key}`);
  if (value === null || value === undefined) {
    return NextResponse.json({ error: "پیدا نشد" }, { status: 404 });
  }
  return NextResponse.json({ key, value });
}

export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return NextResponse.json({ error: "بدنه‌ی درخواست باید JSON باشه" }, { status: 400 });
  }
  const { key, value } = body || {};
  if (!key) {
    return NextResponse.json({ error: "پارامتر key لازمه" }, { status: 400 });
  }
  await kv.set(`${PREFIX}${key}`, value);
  return NextResponse.json({ key, value });
}

export async function DELETE(req) {
  const { searchParams } = new URL(req.url);
  const key = searchParams.get("key");
  if (!key) {
    return NextResponse.json({ error: "پارامتر key لازمه" }, { status: 400 });
  }
  await kv.del(`${PREFIX}${key}`);
  return NextResponse.json({ key, deleted: true });
}
