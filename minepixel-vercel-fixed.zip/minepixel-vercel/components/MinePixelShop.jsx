"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  ShoppingCart, X, Plus, Minus, Sparkles, ShieldCheck, Zap, LogOut,
  Upload, Trash2, Package, Check, Gem, Flame, Star, Copy, CreditCard,
  Wallet, ClipboardList, User as UserIcon, Mail, KeyRound, Lock, ImageOff,
  Percent, Pencil, Tag, Ticket,
} from "lucide-react";

/* ---------------------------------------------------------
   MinePixel — فروشگاه آیتم‌های ماین‌کرافت
   ⚠️ این فایل، نسخه‌ی «تست/نمایشی» است — فقط برای پیش‌نمایش داخل
   همین محیط ساخته شده و از window.storage (که مخصوص همینجاست) استفاده
   می‌کنه. ایمیل واقعی ارسال نمی‌کنه (کد فراموشی رو به‌جای ایمیل، توی
   یک نوتیفیکیشن روی صفحه نشون می‌ده) و ورود با گوگل هم واقعی نیست.
   نسخه‌ی واقعی و قابل‌انتشار روی Vercel، فایل جداگانه‌ست.
--------------------------------------------------------- */

/* ---------------------------------------------------------
   Storage واقعی برای نسخه‌ی Vercel
   - shared=true  (محصولات، کاربران، سفارش‌ها، کدهای تخفیف، کیف پول):
     باید بین همه‌ی کاربرها و مرورگرها مشترک باشه (وگرنه ادمین روی
     گوشیِ خودش سفارش‌های ثبت‌شده از گوشیِ مشتری رو نمی‌بینه) — پس
     از API داخلی /api/storage که پشتش Redis (Upstash) هست استفاده می‌کنیم.
   - shared=false (سبد خرید، سشن ورود، نام اکانت ماین‌کرافت):
     فقط مخصوص همین مرورگره، نیازی به سرور نداره — با localStorage
     ذخیره می‌شه، سریع‌تره و کوتای KV رو هم مصرف نمی‌کنه.
--------------------------------------------------------- */
if (typeof window !== "undefined" && !window.storage) {
  const LOCAL_PREFIX = "minepixel_local__";

  window.storage = {
    async get(key, shared) {
      if (!shared) {
        const raw = window.localStorage.getItem(LOCAL_PREFIX + key);
        if (raw === null) throw new Error("key not found: " + key);
        return { key, value: raw, shared: false };
      }
      const res = await fetch(`/api/storage?key=${encodeURIComponent(key)}`);
      if (!res.ok) throw new Error("key not found: " + key);
      const data = await res.json();
      return { key, value: data.value, shared: true };
    },

    async set(key, value, shared) {
      if (!shared) {
        window.localStorage.setItem(LOCAL_PREFIX + key, value);
        return { key, value, shared: false };
      }
      const res = await fetch("/api/storage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (!res.ok) throw new Error("failed to save: " + key);
      return { key, value, shared: true };
    },

    async delete(key, shared) {
      if (!shared) {
        window.localStorage.removeItem(LOCAL_PREFIX + key);
        return { key, deleted: true, shared: false };
      }
      await fetch(`/api/storage?key=${encodeURIComponent(key)}`, { method: "DELETE" });
      return { key, deleted: true, shared: true };
    },

    async list(prefix, shared) {
      if (!shared) {
        const p = LOCAL_PREFIX + (prefix || "");
        const keys = Object.keys(window.localStorage)
          .filter((k) => k.startsWith(p))
          .map((k) => k.slice(LOCAL_PREFIX.length));
        return { keys, prefix, shared: false };
      }
      const res = await fetch(`/api/storage?list=1&prefix=${encodeURIComponent(prefix || "")}`);
      const data = await res.json();
      return { keys: data.keys || [], prefix, shared: true };
    },
  };
}

const COLORS = {
  bg: "#09070f",
  bgSoft: "#0f0b1c",
  surface: "#171029",
  surface2: "#20173a",
  line: "rgba(155,92,255,0.22)",
  purple: "#9b5cff",
  purpleDeep: "#6b21e8",
  pink: "#e34fd1",
  gold: "#ffb020",
  text: "#f3f0ff",
  textDim: "#a99fc9",
};

const RARITY = {
  common: { label: "عادی", color: "#c7d0da" },
  rare: { label: "کمیاب", color: "#4da3ff" },
  epic: { label: "حماسی", color: "#b45dff" },
  legendary: { label: "افسانه‌ای", color: "#ffb020" },
};

const CATEGORIES = [
  { id: "all", label: "همه" },
  { id: "weapon", label: "سلاح" },
  { id: "armor", label: "زره" },
  { id: "material", label: "مواد" },
  { id: "potion", label: "اکسیر" },
];

const ADMIN_EMAIL = "ahmadishayan24790@gmail.com";
const ADMIN_PASSWORD = "shayan1390";
const ADMIN_NAME = "Admin";
const CARD_NUMBER = "6219861359433736";

function fmtCard(num) {
  return num.replace(/(.{4})/g, "$1 ").trim();
}

/* ---------- اسکرول نرم سفارشی ---------- */
function smoothScrollTo(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const startY = window.scrollY;
  const targetY = el.getBoundingClientRect().top + startY - 76;
  const distance = targetY - startY;
  const duration = 900;
  let startTime = null;
  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  function step(ts) {
    if (startTime === null) startTime = ts;
    const elapsed = ts - startTime;
    const progress = Math.min(elapsed / duration, 1);
    window.scrollTo(0, startY + distance * ease(progress));
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function useReveal() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.unobserve(node);
        }
      },
      { threshold: 0.15 }
    );
    obs.observe(node);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
}

function fmt(n) {
  return n.toLocaleString("fa-IR");
}

// قیمت نهایی یک محصول بعد از اعمال تخفیف مستقیمی که ادمین روی خودش گذاشته
function getEffectivePrice(product) {
  if (!product) return 0;
  if (!product.discountType || product.discountType === "none" || !product.discountValue) {
    return product.price;
  }
  const value = Number(product.discountValue) || 0;
  if (product.discountType === "percent") {
    return Math.max(0, Math.round(product.price - (product.price * value) / 100));
  }
  return Math.max(0, Math.round(product.price - value));
}

export default function MinePixelShop() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [discountCodes, setDiscountCodes] = useState([]);
  const [walletRequests, setWalletRequests] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loaded, setLoaded] = useState(false);

  const [cartOpen, setCartOpen] = useState(false);
  const [filter, setFilter] = useState("all");
  const [authMode, setAuthMode] = useState("login"); // login | signup | forgot
  const [forgotStep, setForgotStep] = useState(1); // 1: email, 2: code + new password
  const [showAuth, setShowAuth] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null); // محصولی که در حال ویرایشه
  const [showCheckout, setShowCheckout] = useState(false);
  const [showOrders, setShowOrders] = useState(false);
  const [showDiscounts, setShowDiscounts] = useState(false);
  const [showWallet, setShowWallet] = useState(false); // مودال شارژ کیف پول کاربر
  const [showWalletRequests, setShowWalletRequests] = useState(false); // مودال بررسی درخواست‌های شارژ (ادمین)
  const [cartCodeInput, setCartCodeInput] = useState("");
  const [appliedCode, setAppliedCode] = useState(null); // کد تخفیفی که روی سبد خرید اعمال شده
  const [minecraftName, setMinecraftName] = useState("");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [forgotForm, setForgotForm] = useState({ email: "", code: "", newPassword: "", confirm: "" });
  const [pendingResetCode, setPendingResetCode] = useState(null); // { email, code } — فقط برای شبیه‌سازی محلی
  const [authError, setAuthError] = useState("");
  const [toast, setToast] = useState(null);
  const [heroIn, setHeroIn] = useState(false);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const heroRef = useRef(null);
  const toastTimer = useRef(null);

  const isAdmin = !!(currentUser && currentUser.email === ADMIN_EMAIL);
  const myWalletBalance = currentUser ? (users.find((u) => u.email === currentUser.email)?.wallet || 0) : 0;
  const pendingWalletRequests = walletRequests.filter((w) => w.status === "در انتظار تأیید واریز");

  useEffect(() => {
    document.title = "ماین‌پیکسل | فروشگاه آیتم‌های ماین‌کرافت";
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "description";
      document.head.appendChild(meta);
    }
    meta.content = "ماین‌پیکسل — فروشگاه خرید آیتم‌های ماین‌کرافت: شمشیر، زره، اکسیر و مواد کمیاب با تحویل آنی.";
  }, []);

  const showToast = useCallback((msg, duration = 2800) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), duration);
  }, []);

  /* بارگذاری اولیه */
  useEffect(() => {
    (async () => {
      let p = [];
      let c = [];
      let u = [{ name: ADMIN_NAME, email: ADMIN_EMAIL, password: ADMIN_PASSWORD, pwHistory: [], wallet: 0 }];
      let o = [];
      let d = [];
      let w = [];
      let session = null;
      let mcName = "";
      try {
        const res = await window.storage.get("minepixel-products", true);
        if (res && res.value) p = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-cart", false);
        if (res && res.value) c = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-users", true);
        if (res && res.value) {
          const stored = JSON.parse(res.value);
          if (Array.isArray(stored) && stored.length) u = stored;
        }
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-orders", true);
        if (res && res.value) o = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-discounts", true);
        if (res && res.value) d = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-wallet-requests", true);
        if (res && res.value) w = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-session", false);
        if (res && res.value) session = JSON.parse(res.value);
      } catch (e) {}
      try {
        const res = await window.storage.get("minepixel-mcname", false);
        if (res && res.value) mcName = JSON.parse(res.value);
      } catch (e) {}
      u = u.map((x) => ({ wallet: 0, ...x }));
      setProducts(p);
      setCart(c);
      setUsers(u);
      setOrders(o);
      setDiscountCodes(d);
      setWalletRequests(w);
      setCurrentUser(session);
      setMinecraftName(mcName);
      setLoaded(true);
      try {
        await window.storage.set("minepixel-users", JSON.stringify(u), true);
      } catch (e) {}
    })();
    const t = setTimeout(() => setHeroIn(true), 150);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => { if (loaded) window.storage.set("minepixel-products", JSON.stringify(products), true).catch(() => {}); }, [products, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-cart", JSON.stringify(cart), false).catch(() => {}); }, [cart, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-users", JSON.stringify(users), true).catch(() => {}); }, [users, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-orders", JSON.stringify(orders), true).catch(() => {}); }, [orders, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-discounts", JSON.stringify(discountCodes), true).catch(() => {}); }, [discountCodes, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-wallet-requests", JSON.stringify(walletRequests), true).catch(() => {}); }, [walletRequests, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-session", JSON.stringify(currentUser), false).catch(() => {}); }, [currentUser, loaded]);
  useEffect(() => { if (loaded) window.storage.set("minepixel-mcname", JSON.stringify(minecraftName), false).catch(() => {}); }, [minecraftName, loaded]);

  const handleHeroMove = (e) => {
    const rect = heroRef.current?.getBoundingClientRect();
    if (!rect) return;
    setParallax({ x: (e.clientX - rect.left) / rect.width - 0.5, y: (e.clientY - rect.top) / rect.height - 0.5 });
  };

  const addToCart = (product) => {
    setCart((prev) => {
      const found = prev.find((i) => i.id === product.id);
      if (found) return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { id: product.id, qty: 1 }];
    });
    showToast(`«${product.name}» به سبد اضافه شد`);
  };

  const changeQty = (id, delta) =>
    setCart((prev) => prev.map((i) => (i.id === id ? { ...i, qty: i.qty + delta } : i)).filter((i) => i.qty > 0));
  const removeFromCart = (id) => setCart((prev) => prev.filter((i) => i.id !== id));

  const cartItems = cart.map((c) => ({ ...c, product: products.find((p) => p.id === c.id) })).filter((c) => c.product);
  const cartCount = cartItems.reduce((s, i) => s + i.qty, 0);
  const cartSubtotal = cartItems.reduce((s, i) => s + i.qty * getEffectivePrice(i.product), 0);
  const codeDiscountAmount = appliedCode
    ? appliedCode.type === "percent"
      ? Math.round((cartSubtotal * appliedCode.value) / 100)
      : Math.min(cartSubtotal, appliedCode.value)
    : 0;
  const cartTotal = Math.max(0, cartSubtotal - codeDiscountAmount);

  const openCheckout = () => {
    if (cartItems.length === 0) return;
    if (!currentUser) {
      setShowAuth(true);
      setAuthMode("login");
      showToast("برای ثبت سفارش، اول وارد حسابت شو");
      return;
    }
    if (!minecraftName.trim()) {
      showToast("قبل از خرید، نام اکانت ماین‌کرافتت رو وارد کن");
      return;
    }
    setCartOpen(false);
    setShowCheckout(true);
  };

  // فعلاً فقط کارت‌به‌کارت فعاله و فقط با عکس رسید واریز
  const placeOrder = (method, receiptImage) => {
    if (method !== "card2card") {
      showToast("پرداخت از طریق درگاه اینترنتی فعلاً غیرفعاله");
      return;
    }
    if (!receiptImage) {
      showToast("قبل از ثبت سفارش، عکس رسید واریز رو آپلود کن");
      return;
    }
    const order = {
      id: "o" + Date.now(),
      buyerEmail: currentUser.email,
      buyerName: currentUser.name,
      minecraftName: minecraftName.trim(),
      items: cartItems.map((i) => ({ name: i.product.name, qty: i.qty, price: getEffectivePrice(i.product) })),
      discountCode: appliedCode ? appliedCode.code : null,
      discountAmount: codeDiscountAmount,
      total: cartTotal,
      method: "card2card",
      receiptImage,
      status: "در انتظار تأیید واریز",
      date: new Date().toISOString(),
    };
    setOrders((prev) => [order, ...prev]);
    setCart([]);
    setAppliedCode(null);
    setShowCheckout(false);
    showToast("سفارش ثبت شد؛ پس از تأیید واریز توسط ادمین پردازش می‌شود");
  };

  const confirmOrder = (id) => {
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status: "پرداخت تأیید شد" } : o)));
    showToast("سفارش تأیید شد");
  };

  /* ---------- کیف پول ---------- */
  const requestWalletCharge = (amount, receiptImage) => {
    if (!currentUser) return;
    if (!amount || amount <= 0) {
      showToast("مبلغ شارژ رو درست وارد کن");
      return;
    }
    if (!receiptImage) {
      showToast("قبل از ثبت درخواست، عکس رسید واریز رو آپلود کن");
      return;
    }
    const req = {
      id: "w" + Date.now(),
      buyerEmail: currentUser.email,
      buyerName: currentUser.name,
      amount,
      receiptImage,
      status: "در انتظار تأیید واریز",
      date: new Date().toISOString(),
    };
    setWalletRequests((prev) => [req, ...prev]);
    setShowWallet(false);
    // «پیام» به ادمین: درخواست در پنل «درخواست‌های کیف پول» ادمین (که با یک نشان قرمز مشخصه) ظاهر می‌شه.
    showToast(`درخواست شارژ ${fmt(amount)} تومانی ثبت شد؛ پس از تأیید ادمین به کیف پولت اضافه می‌شه`, 4000);
  };

  const confirmWalletRequest = (id) => {
    const req = walletRequests.find((w) => w.id === id);
    if (!req) return;
    setUsers((prev) => prev.map((u) => (u.email === req.buyerEmail ? { ...u, wallet: (u.wallet || 0) + req.amount } : u)));
    setWalletRequests((prev) => prev.map((w) => (w.id === id ? { ...w, status: "پرداخت تأیید شد" } : w)));
    showToast(`کیف پول ${req.buyerName} به مقدار ${fmt(req.amount)} تومان شارژ شد ✅`);
  };

  // شارژ دستی کیف پول توسط ادمین (بدون نیاز به درخواست/رسید کاربر)
  const adminChargeWallet = (email, amount) => {
    const value = Number(amount);
    if (!email) {
      showToast("یک کاربر رو انتخاب کن");
      return false;
    }
    if (!value || value === 0) {
      showToast("مبلغ رو درست وارد کن");
      return false;
    }
    const target = users.find((u) => u.email === email);
    if (!target) {
      showToast("کاربر پیدا نشد");
      return false;
    }
    setUsers((prev) => prev.map((u) => (u.email === email ? { ...u, wallet: Math.max(0, (u.wallet || 0) + value) } : u)));
    showToast(`کیف پول ${target.name} به مقدار ${fmt(value)} تومان ${value > 0 ? "شارژ شد" : "کسر شد"} ✅`);
    return true;
  };

  /* ---------- کدهای تخفیف (ادمین) ---------- */
  const addDiscountCode = (data) => {
    const code = data.code.trim().toUpperCase();
    if (!code) {
      showToast("کد تخفیف رو وارد کن");
      return false;
    }
    if (discountCodes.some((d) => d.code === code)) {
      showToast("این کد تخفیف قبلاً ساخته شده");
      return false;
    }
    const value = Number(data.value);
    if (!value || value <= 0) {
      showToast("مقدار تخفیف باید بزرگ‌تر از صفر باشه");
      return false;
    }
    if (data.type === "percent" && value > 100) {
      showToast("درصد تخفیف نمی‌تونه بیشتر از ۱۰۰ باشه");
      return false;
    }
    const newCode = { id: "d" + Date.now(), code, type: data.type, value, active: true };
    setDiscountCodes((prev) => [newCode, ...prev]);
    showToast("کد تخفیف ساخته شد ✅");
    return true;
  };

  const updateDiscountCode = (id, data) => {
    setDiscountCodes((prev) => prev.map((d) => (d.id === id ? { ...d, ...data } : d)));
  };

  const deleteDiscountCode = (id) => {
    setDiscountCodes((prev) => prev.filter((d) => d.id !== id));
    if (appliedCode && discountCodes.find((d) => d.id === id)?.code === appliedCode.code) {
      setAppliedCode(null);
    }
    showToast("کد تخفیف حذف شد");
  };

  const applyDiscountCode = (rawCode) => {
    const code = rawCode.trim().toUpperCase();
    if (!code) return;
    const found = discountCodes.find((d) => d.code === code);
    if (!found || !found.active) {
      showToast("کد تخفیف نامعتبر یا غیرفعاله");
      return;
    }
    setAppliedCode(found);
    showToast(`کد «${found.code}» اعمال شد 🎉`);
  };

  const removeAppliedCode = () => setAppliedCode(null);

  /* ---------- احراز هویت ---------- */
  const handleLogin = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    const email = authForm.email.trim().toLowerCase();
    const found = users.find((u) => u.email.toLowerCase() === email && u.password === authForm.password);
    if (!found) {
      setAuthError("ایمیل یا رمز عبور اشتباهه");
      return;
    }
    setCurrentUser({ name: found.name, email: found.email });
    setShowAuth(false);
    setAuthError("");
    setAuthForm({ name: "", email: "", password: "", confirm: "" });
    showToast(`خوش اومدی، ${found.name}`);
  };

  const handleSignup = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    const name = authForm.name.trim();
    const email = authForm.email.trim().toLowerCase();
    if (!name || !email || !authForm.password) {
      setAuthError("همه فیلدها رو پر کن");
      return;
    }
    if (authForm.password !== authForm.confirm) {
      setAuthError("تکرار رمز عبور مطابقت نداره");
      return;
    }
    if (authForm.password.length < 4) {
      setAuthError("رمز عبور باید حداقل ۴ کاراکتر باشه");
      return;
    }
    const dupName = users.some((u) => u.name.trim().toLowerCase() === name.toLowerCase());
    const dupEmail = users.some((u) => u.email.toLowerCase() === email);
    if (dupName || dupEmail) {
      setAuthError("این نام یا ایمیل قبلاً استفاده شده");
      return;
    }
    const newUser = { name, email, password: authForm.password, pwHistory: [], wallet: 0 };
    setUsers((prev) => [...prev, newUser]);
    setCurrentUser({ name, email });
    setShowAuth(false);
    setAuthError("");
    setAuthForm({ name: "", email: "", password: "", confirm: "" });
    showToast(`حساب ساخته شد، خوش اومدی ${name}`);
  };

  const handleGoogle = () => {
    showToast("ورود با گوگل نیازمند سرور واقعی است — در این نسخه‌ی تستی فعال نیست (نسخه‌ی Vercel، ورود واقعی با گوگل داره)");
  };

  /* ---------- فراموشی رمز عبور (شبیه‌سازی محلی — بدون ایمیل واقعی) ---------- */
  const sendResetCode = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    setAuthError("");
    const email = forgotForm.email.trim().toLowerCase();
    const found = users.find((u) => u.email.toLowerCase() === email);
    if (!found) {
      // به‌عمد نمی‌گیم ایمیل پیدا نشد، مثل نسخه‌ی واقعی
      setForgotStep(2);
      showToast("اگه این ایمیل ثبت‌نام شده باشه، کد براش ارسال می‌شه");
      return;
    }
    const code = String(Math.floor(100000 + Math.random() * 900000));
    setPendingResetCode({ email, code, createdAt: Date.now() });
    setForgotStep(2);
    showToast(`📩 (شبیه‌سازی ایمیل) کد تأیید تو: ${code}`, 8000);
  };

  const submitReset = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    setAuthError("");
    const email = forgotForm.email.trim().toLowerCase();
    if (!forgotForm.code.trim()) {
      setAuthError("کد تأیید رو وارد کن");
      return;
    }
    if (!pendingResetCode || pendingResetCode.email !== email || pendingResetCode.code !== forgotForm.code.trim()) {
      setAuthError("کد وارد شده اشتباهه");
      return;
    }
    if (Date.now() - pendingResetCode.createdAt > 10 * 60 * 1000) {
      setAuthError("کد منقضی شده، یک کد جدید بگیر");
      return;
    }
    if (forgotForm.newPassword.length < 4) {
      setAuthError("رمز عبور جدید باید حداقل ۴ کاراکتر باشه");
      return;
    }
    if (forgotForm.newPassword !== forgotForm.confirm) {
      setAuthError("تکرار رمز عبور مطابقت نداره");
      return;
    }
    const found = users.find((u) => u.email.toLowerCase() === email);
    if (!found) {
      setAuthError("کاربری با این ایمیل پیدا نشد");
      return;
    }
    const history = found.pwHistory || [];
    const reused = found.password === forgotForm.newPassword || history.includes(forgotForm.newPassword);
    if (reused) {
      setAuthError("این رمز عبور قبلاً استفاده شده. یک رمز عبور جدید انتخاب کن");
      return;
    }
    setUsers((prev) =>
      prev.map((u) =>
        u.email.toLowerCase() === email
          ? { ...u, password: forgotForm.newPassword, pwHistory: [u.password, ...history].slice(0, 5) }
          : u
      )
    );
    setPendingResetCode(null);
    setAuthMode("login");
    setForgotStep(1);
    setAuthForm((f) => ({ ...f, email }));
    setForgotForm({ email: "", code: "", newPassword: "", confirm: "" });
    showToast("رمز عبور با موفقیت تغییر کرد، حالا وارد شو");
  };

  const logout = () => {
    setCurrentUser(null);
    showToast("از حساب خارج شدی");
  };

  const deleteProduct = (id) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    showToast("محصول حذف شد");
  };

  const editProduct = (id, updated) => {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...updated } : p)));
    showToast("محصول ویرایش شد ✅");
  };

  const filteredProducts = filter === "all" ? products : products.filter((p) => p.category === filter);
  const pendingOrders = orders.filter((o) => o.status === "در انتظار تأیید واریز");

  return (
    <div dir="rtl" style={{ background: COLORS.bg, color: COLORS.text, minHeight: "100vh", fontFamily: "'Vazirmatn', sans-serif", overflowX: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&family=Press+Start+2P&display=swap');
        * { box-sizing: border-box; }
        ::selection { background: ${COLORS.purple}; color: white; }
        .pixel { font-family: 'Press Start 2P', monospace; }
        .reveal { opacity: 0; transform: translateY(28px); transition: opacity .7s cubic-bezier(.22,1,.36,1), transform .7s cubic-bezier(.22,1,.36,1); }
        .reveal.in { opacity: 1; transform: translateY(0); }
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .marquee-track { display: flex; width: max-content; animation: marquee 22s linear infinite; }
        @keyframes floaty { 0%,100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-16px) rotate(4deg); } }
        @keyframes pulseGlow { 0%,100% { opacity: .55; } 50% { opacity: .95; } }
        .kinetic-line { overflow: hidden; }
        .kinetic-line span { display: inline-block; transform: translateY(100%); opacity: 0; transition: transform .8s cubic-bezier(.16,1,.3,1), opacity .8s ease; }
        .kinetic-line.in span { transform: translateY(0); opacity: 1; }
        .card-hover { transition: transform .35s cubic-bezier(.16,1,.3,1), box-shadow .35s ease, border-color .35s ease; }
        .card-hover:hover { transform: translateY(-6px); border-color: ${COLORS.purple} !important; box-shadow: 0 20px 50px -15px rgba(155,92,255,0.35); }
        .btn-primary { transition: transform .25s ease, box-shadow .25s ease, background .25s ease; }
        .btn-primary:hover { transform: translateY(-2px) scale(1.02); box-shadow: 0 12px 30px -8px rgba(155,92,255,0.6); }
        .scrollbar-thin::-webkit-scrollbar { width: 6px; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: ${COLORS.purple}; border-radius: 10px; }
        input, select, textarea { font-family: 'Vazirmatn', sans-serif; }
        @media (prefers-reduced-motion: reduce) {
          .reveal, .kinetic-line span, .marquee-track { animation: none !important; transition: none !important; opacity: 1 !important; transform: none !important; }
        }
      `}</style>

      {/* ---------- Navbar ---------- */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, backdropFilter: "blur(14px)", background: "rgba(9,7,15,0.75)", borderBottom: `1px solid ${COLORS.line}` }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div className="pixel" style={{ fontSize: 13, color: COLORS.purple, letterSpacing: 1, display: "flex", alignItems: "center", gap: 8 }}>
            <Gem size={20} color={COLORS.pink} /> MINEPIXEL
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {isAdmin && (
              <button onClick={() => setShowOrders(true)} style={iconBtnStyle} title="خرید مشتری">
                <ClipboardList size={18} />
                {pendingOrders.length > 0 && (
                  <span style={dotBadge}>{pendingOrders.length}</span>
                )}
              </button>
            )}
            {isAdmin && (
              <button onClick={() => setShowDiscounts(true)} style={iconBtnStyle} title="پنل تخفیف">
                <Percent size={18} />
              </button>
            )}
            {isAdmin && (
              <button onClick={() => setShowWalletRequests(true)} style={iconBtnStyle} title="درخواست‌های شارژ کیف پول">
                <Wallet size={18} />
                {pendingWalletRequests.length > 0 && (
                  <span style={dotBadge}>{pendingWalletRequests.length}</span>
                )}
              </button>
            )}
            {currentUser && (
              <button onClick={() => setShowWallet(true)} style={{ ...iconBtnStyle, display: "flex", alignItems: "center", gap: 6, width: "auto", padding: "8px 12px" }} title="کیف پول">
                <Wallet size={16} />
                <span style={{ fontSize: 12.5, fontWeight: 700, color: COLORS.gold }}>{fmt(myWalletBalance)}</span>
              </button>
            )}
            <button onClick={() => setCartOpen(true)} style={{ ...iconBtnStyle, position: "relative" }} title="سبد خرید">
              <ShoppingCart size={18} />
              {cartCount > 0 && <span style={dotBadge}>{cartCount}</span>}
            </button>
            {currentUser ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 13, color: COLORS.textDim, display: "flex", alignItems: "center", gap: 6 }}>
                  <UserIcon size={14} /> {currentUser.name}{isAdmin && <span style={{ color: COLORS.gold, fontSize: 11 }}>(ادمین)</span>}
                </span>
                <button onClick={logout} style={iconBtnStyle} title="خروج"><LogOut size={16} /></button>
              </div>
            ) : (
              <button
                onClick={() => { setShowAuth(true); setAuthMode("login"); setAuthError(""); }}
                style={{ background: "none", border: "none", color: COLORS.text, fontSize: 14.5, fontWeight: 600, cursor: "pointer" }}
              >
                ورود
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* ---------- Hero ---------- */}
      <section id="home" ref={heroRef} onMouseMove={handleHeroMove} style={{ position: "relative", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "120px 20px 60px", overflow: "hidden" }}>
        <div style={{
          position: "absolute", top: "50%", left: "50%", width: 620, height: 620,
          transform: `translate(-50%,-50%) translate(${parallax.x * 20}px, ${parallax.y * 20}px)`,
          background: `radial-gradient(circle, ${COLORS.purple}55 0%, ${COLORS.purpleDeep}22 40%, transparent 70%)`,
          filter: "blur(40px)", animation: "pulseGlow 4s ease-in-out infinite", pointerEvents: "none",
        }} />
        {[
          { icon: "💎", top: "20%", left: "12%", size: 46, depth: 30 },
          { icon: "⚔️", top: "65%", left: "10%", size: 40, depth: -24 },
          { icon: "🟪", top: "18%", left: "85%", size: 44, depth: -20 },
          { icon: "🔮", top: "70%", left: "88%", size: 38, depth: 26 },
          { icon: "🧪", top: "40%", left: "92%", size: 34, depth: 16 },
        ].map((b, idx) => (
          <div key={idx} style={{
            position: "absolute", top: b.top, left: b.left, fontSize: b.size,
            transform: `translate(${parallax.x * b.depth}px, ${parallax.y * b.depth}px)`,
            animation: `floaty ${3.5 + idx * 0.4}s ease-in-out infinite`, animationDelay: `${idx * 0.3}s`,
            filter: "drop-shadow(0 0 14px rgba(155,92,255,0.5))", pointerEvents: "none",
          }}>{b.icon}</div>
        ))}

        <div style={{ position: "relative", zIndex: 2, textAlign: "center", maxWidth: 760 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 16px", borderRadius: 999, border: `1px solid ${COLORS.line}`, background: "rgba(155,92,255,0.08)", marginBottom: 24, fontSize: 13, color: COLORS.textDim }}>
            <Sparkles size={14} color={COLORS.gold} /> فروشگاه آیتم‌های درون‌بازی ماین‌کرافت
          </div>
          <h1 style={{ fontSize: "clamp(34px, 6vw, 62px)", fontWeight: 900, lineHeight: 1.25, margin: "0 0 20px" }}>
            {["بهترین آیتم‌های ماین‌کرافت،", "همین حالا در دستِ توئه"].map((line, i) => (
              <div key={i} className={`kinetic-line ${heroIn ? "in" : ""}`} style={{ transitionDelay: `${i * 0.15}s` }}>
                <span style={{ transitionDelay: `${i * 0.15}s`, background: i === 1 ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : "none", WebkitBackgroundClip: i === 1 ? "text" : "unset", WebkitTextFillColor: i === 1 ? "transparent" : "unset" }}>{line}</span>
              </div>
            ))}
          </h1>
          <p style={{ color: COLORS.textDim, fontSize: 17, lineHeight: 1.9, marginBottom: 34 }}>
            شمشیر افسون‌شده، زره نتریت، اکسیر و مواد کمیاب — تحویل آنی به دنیای بازی‌ت.
          </p>
          <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
            <button onClick={() => smoothScrollTo("shop")} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, color: "white", border: "none", padding: "14px 30px", borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: "pointer" }}>مشاهده فروشگاه</button>
            <button onClick={() => smoothScrollTo("why")} className="btn-primary" style={{ background: "transparent", color: COLORS.text, border: `1px solid ${COLORS.line}`, padding: "14px 30px", borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: "pointer" }}>چرا ما؟</button>
          </div>
        </div>
      </section>

      {/* ---------- Marquee ---------- */}
      <div style={{ borderTop: `1px solid ${COLORS.line}`, borderBottom: `1px solid ${COLORS.line}`, background: COLORS.surface, padding: "14px 0", overflow: "hidden" }}>
        <div className="marquee-track">
          {[...Array(2)].map((_, r) => (
            <div key={r} style={{ display: "flex", gap: 48, paddingInlineEnd: 48 }}>
              {["ارسال آنی", "قیمت مناسب", "پشتیبانی ۲۴/۷", "تضمین امنیت اکانت", "تحویل مطمئن"].map((t, i) => (
                <span key={i} className="pixel" style={{ fontSize: 12, color: COLORS.textDim, whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 10 }}><Star size={12} color={COLORS.gold} /> {t}</span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ---------- چرا ما ---------- */}
      <section id="why" style={{ maxWidth: 1100, margin: "0 auto", padding: "110px 20px" }}>
        <SectionHeading eyebrow="چرا ما" title="فصل‌های اعتماد" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24, marginTop: 50 }}>
          {[
            { n: "۰۱", icon: <Zap size={22} color={COLORS.purple} />, title: "تحویل آنی", desc: "آیتم‌ها معمولاً در کمتر از چند دقیقه به دنیای بازیت اضافه می‌شن." },
            { n: "۰۲", icon: <ShieldCheck size={22} color={COLORS.purple} />, title: "امنیت اکانت", desc: "هیچ‌وقت رمز عبور یا اطلاعات حساس ازت نمی‌خوایم." },
            { n: "۰۳", icon: <Flame size={22} color={COLORS.purple} />, title: "کیفیت تضمینی", desc: "همه آیتم‌ها قبل از تحویل بررسی و تست می‌شن." },
          ].map((f, i) => <FeatureCard key={i} f={f} i={i} />)}
        </div>
      </section>

      {/* ---------- فروشگاه ---------- */}
      <section id="shop" style={{ maxWidth: 1180, margin: "0 auto", padding: "60px 20px 110px" }}>
        <SectionHeading eyebrow="فروشگاه" title="آیتم‌های موجود" />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16, margin: "40px 0 30px" }}>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {CATEGORIES.map((c) => (
              <button key={c.id} onClick={() => setFilter(c.id)} style={{
                padding: "8px 18px", borderRadius: 999, fontSize: 13, cursor: "pointer", fontWeight: 600,
                border: `1px solid ${filter === c.id ? COLORS.purple : COLORS.line}`,
                background: filter === c.id ? "rgba(155,92,255,0.18)" : "transparent",
                color: filter === c.id ? COLORS.text : COLORS.textDim, transition: "all .25s ease",
              }}>{c.label}</button>
            ))}
          </div>
          {isAdmin && (
            <button onClick={() => setShowAddProduct(true)} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 8, background: COLORS.surface2, color: COLORS.text, border: `1px solid ${COLORS.purple}`, padding: "10px 18px", borderRadius: 10, cursor: "pointer", fontSize: 14, fontWeight: 600 }}>
              <Plus size={16} /> افزودن به فروش
            </button>
          )}
        </div>

        {filteredProducts.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 20px", border: `1px dashed ${COLORS.line}`, borderRadius: 18 }}>
            <Package size={30} color={COLORS.textDim} style={{ marginBottom: 12 }} />
            <p style={{ color: COLORS.textDim, fontSize: 14 }}>
              {isAdmin ? "هنوز آیتمی اضافه نکردی — از دکمه «افزودن به فروش» شروع کن." : "هنوز آیتمی برای فروش اضافه نشده. به‌زودی برمی‌گردیم!"}
            </p>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: 20 }}>
            {filteredProducts.map((p, i) => (
              <ProductCard key={p.id} p={p} i={i} isAdmin={isAdmin} onDelete={deleteProduct} onAdd={addToCart} onEdit={() => setEditingProduct(p)} />
            ))}
          </div>
        )}
      </section>

      {/* ---------- فوتر ---------- */}
      <footer id="contact" style={{ borderTop: `1px solid ${COLORS.line}`, padding: "50px 20px", textAlign: "center" }}>
        <div className="pixel" style={{ fontSize: 13, color: COLORS.purple, marginBottom: 14 }}>MINEPIXEL</div>
        <p style={{ color: COLORS.textDim, fontSize: 13.5 }}>پشتیبانی: support@minepixel.ir — پاسخگویی ۲۴ ساعته</p>
        <p style={{ color: "#5c5470", fontSize: 12, marginTop: 18 }}>© {new Date().getFullYear()} MinePixel — همه حقوق محفوظ است.</p>
      </footer>

      {/* ---------- سبد خرید ---------- */}
      <div style={{ position: "fixed", inset: 0, zIndex: 100, pointerEvents: cartOpen ? "auto" : "none" }}>
        <div onClick={() => setCartOpen(false)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.55)", opacity: cartOpen ? 1 : 0, transition: "opacity .35s ease" }} />
        <div className="scrollbar-thin" style={{ position: "absolute", top: 0, bottom: 0, right: 0, width: "min(380px, 90vw)", background: COLORS.bgSoft, borderLeft: `1px solid ${COLORS.line}`, padding: 24, transform: cartOpen ? "translateX(0)" : "translateX(100%)", transition: "transform .4s cubic-bezier(.16,1,.3,1)", display: "flex", flexDirection: "column", overflowY: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <h3 style={{ fontSize: 18, fontWeight: 800 }}>سبد خرید</h3>
            <button onClick={() => setCartOpen(false)} style={iconBtnStyle}><X size={18} /></button>
          </div>
          {cartItems.length === 0 ? (
            <p style={{ color: COLORS.textDim, textAlign: "center", marginTop: 60 }}>سبد خریدت خالیه.</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 14, flex: 1 }}>
              {cartItems.map((item) => (
                <div key={item.id} style={{ display: "flex", gap: 12, background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12, alignItems: "center" }}>
                  <div style={{ fontSize: 26, width: 44, textAlign: "center" }}>
                    {item.product.image ? <img src={item.product.image} style={{ width: 36, height: 36, objectFit: "cover", borderRadius: 6 }} /> : item.product.icon}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{item.product.name}</div>
                    {getEffectivePrice(item.product) < item.product.price ? (
                      <div style={{ fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ color: COLORS.textDim, textDecoration: "line-through" }}>{fmt(item.product.price)}</span>
                        <span style={{ color: COLORS.gold, fontWeight: 700 }}>{fmt(getEffectivePrice(item.product))} تومان</span>
                      </div>
                    ) : (
                      <div style={{ fontSize: 12, color: COLORS.textDim }}>{fmt(item.product.price)} تومان</div>
                    )}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <button onClick={() => changeQty(item.id, -1)} style={qtyBtnStyle}><Minus size={12} /></button>
                    <span style={{ fontSize: 13, minWidth: 16, textAlign: "center" }}>{item.qty}</span>
                    <button onClick={() => changeQty(item.id, 1)} style={qtyBtnStyle}><Plus size={12} /></button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} style={{ background: "none", border: "none", color: "#ff6b6b", cursor: "pointer" }}><X size={14} /></button>
                </div>
              ))}
            </div>
          )}
          {cartItems.length > 0 && (
            <div style={{ marginTop: 20, borderTop: `1px solid ${COLORS.line}`, paddingTop: 18 }}>
              <label style={{ fontSize: 12.5, color: COLORS.textDim, display: "block", marginBottom: 8 }}>کد تخفیف</label>
              {appliedCode ? (
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "rgba(155,92,255,0.1)", border: `1px solid ${COLORS.purple}`, borderRadius: 10, padding: "9px 12px", marginBottom: 16 }}>
                  <span style={{ fontSize: 12.5, display: "flex", alignItems: "center", gap: 6, color: COLORS.text }}>
                    <Ticket size={13} color={COLORS.purple} /> کد «{appliedCode.code}» اعمال شد
                  </span>
                  <button onClick={removeAppliedCode} style={{ background: "none", border: "none", color: "#ff6b6b", cursor: "pointer", fontSize: 11.5 }}>حذف</button>
                </div>
              ) : (
                <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                  <input
                    placeholder="مثلاً: OFF20"
                    value={cartCodeInput}
                    onChange={(e) => setCartCodeInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { applyDiscountCode(cartCodeInput); setCartCodeInput(""); } }}
                    style={{ ...inputStyle, flex: 1, direction: "ltr", textAlign: "left" }}
                  />
                  <button
                    onClick={() => { applyDiscountCode(cartCodeInput); setCartCodeInput(""); }}
                    disabled={!cartCodeInput.trim()}
                    style={{
                      background: cartCodeInput.trim() ? COLORS.surface2 : "transparent",
                      border: `1px solid ${cartCodeInput.trim() ? COLORS.purple : COLORS.line}`,
                      color: COLORS.text, borderRadius: 10, padding: "0 16px", fontSize: 12.5, fontWeight: 700,
                      cursor: cartCodeInput.trim() ? "pointer" : "not-allowed",
                    }}
                  >
                    اعمال
                  </button>
                </div>
              )}

              <label style={{ fontSize: 12.5, color: COLORS.textDim, display: "block", marginBottom: 8 }}>نام اکانت ماین‌کرافت</label>
              <input
                placeholder="مثلاً: Shayan_MC"
                value={minecraftName}
                onChange={(e) => setMinecraftName(e.target.value)}
                style={{ ...inputStyle, marginBottom: 16 }}
              />
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13, color: COLORS.textDim }}>
                <span>جمع جزء</span><span>{fmt(cartSubtotal)} تومان</span>
              </div>
              {appliedCode && (
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13, color: COLORS.gold }}>
                  <span>تخفیف کد</span><span>- {fmt(codeDiscountAmount)} تومان</span>
                </div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16, fontSize: 15, fontWeight: 700 }}>
                <span>جمع کل</span><span>{fmt(cartTotal)} تومان</span>
              </div>
              <button
                onClick={openCheckout}
                disabled={!minecraftName.trim()}
                className="btn-primary"
                style={{
                  width: "100%", background: minecraftName.trim() ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : COLORS.surface2,
                  border: "none", color: minecraftName.trim() ? "white" : COLORS.textDim, padding: "13px", borderRadius: 12,
                  fontWeight: 700, cursor: minecraftName.trim() ? "pointer" : "not-allowed", fontSize: 14.5,
                }}
              >
                ادامه و پرداخت
              </button>
              {!minecraftName.trim() && (
                <p style={{ fontSize: 11.5, color: COLORS.textDim, textAlign: "center", marginTop: 8 }}>
                  برای ادامه، نام اکانت ماین‌کرافتت رو وارد کن
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ---------- مودال احراز هویت ---------- */}
      {showAuth && (
        <Modal
          title={authMode === "login" ? "ورود به حساب" : authMode === "signup" ? "ساخت حساب" : "فراموشی رمز عبور"}
          onClose={() => { setShowAuth(false); setAuthError(""); setForgotStep(1); }}
        >
          {authMode !== "forgot" && (
            <div style={{ display: "flex", gap: 8, marginBottom: 18, background: COLORS.surface, padding: 4, borderRadius: 10 }}>
              {["login", "signup"].map((m) => (
                <button key={m} onClick={() => { setAuthMode(m); setAuthError(""); }} style={{
                  flex: 1, padding: "8px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 700,
                  background: authMode === m ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : "transparent",
                  color: authMode === m ? "white" : COLORS.textDim,
                }}>{m === "login" ? "ورود" : "ساخت اکانت"}</button>
              ))}
            </div>
          )}

          {authMode !== "forgot" && (
            <>
              <button onClick={handleGoogle} style={{ ...inputStyle, display: "flex", alignItems: "center", justifyContent: "center", gap: 10, cursor: "pointer", fontWeight: 600, marginBottom: 14 }}>
                <span style={{ width: 18, height: 18, borderRadius: "50%", background: "#fff", color: "#111", fontSize: 11, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center" }}>G</span>
                ورود با گوگل
              </button>
              <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "4px 0 14px", color: COLORS.textDim, fontSize: 12 }}>
                <div style={{ flex: 1, height: 1, background: COLORS.line }} /> یا <div style={{ flex: 1, height: 1, background: COLORS.line }} />
              </div>
            </>
          )}

          {authMode === "login" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <input type="email" placeholder="ایمیل" value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} style={inputStyle} />
              <input type="password" placeholder="رمز عبور" value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} onKeyDown={(e) => e.key === "Enter" && handleLogin()} style={inputStyle} />
              <button
                type="button"
                onClick={() => { setAuthMode("forgot"); setForgotStep(1); setAuthError(""); setForgotForm((f) => ({ ...f, email: authForm.email })); }}
                style={{ background: "none", border: "none", color: COLORS.purple, fontSize: 12.5, cursor: "pointer", alignSelf: "flex-start", padding: 0 }}
              >
                رمز عبورت رو فراموش کردی؟
              </button>
              {authError && <p style={{ color: "#ff6b6b", fontSize: 13 }}>{authError}</p>}
              <button type="button" onClick={handleLogin} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>ورود</button>
            </div>
          )}

          {authMode === "signup" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <input placeholder="نام" value={authForm.name} onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })} style={inputStyle} />
              <input type="email" placeholder="ایمیل" value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} style={inputStyle} />
              <input type="password" placeholder="رمز عبور" value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} style={inputStyle} />
              <input type="password" placeholder="تکرار رمز عبور" value={authForm.confirm} onChange={(e) => setAuthForm({ ...authForm, confirm: e.target.value })} onKeyDown={(e) => e.key === "Enter" && handleSignup()} style={inputStyle} />
              {authError && <p style={{ color: "#ff6b6b", fontSize: 13 }}>{authError}</p>}
              <button type="button" onClick={handleSignup} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>ساخت حساب</button>
            </div>
          )}

          {authMode === "forgot" && forgotStep === 1 && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <p style={{ fontSize: 12.5, color: COLORS.textDim, lineHeight: 1.8, marginBottom: 4, display: "flex", gap: 8 }}>
                <Mail size={16} style={{ flexShrink: 0, marginTop: 2 }} />
                ایمیلت رو وارد کن؛ یک کد شش‌رقمی برات ارسال می‌شه (توی این نسخه‌ی تستی، کد به‌جای ایمیل، توی یک نوتیفیکیشن نشون داده می‌شه).
              </p>
              <input type="email" placeholder="ایمیل" value={forgotForm.email} onChange={(e) => setForgotForm({ ...forgotForm, email: e.target.value })} style={inputStyle} />
              {authError && <p style={{ color: "#ff6b6b", fontSize: 13 }}>{authError}</p>}
              <button type="button" onClick={sendResetCode} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>
                ارسال کد
              </button>
              <button type="button" onClick={() => { setAuthMode("login"); setAuthError(""); }} style={{ background: "none", border: "none", color: COLORS.textDim, fontSize: 12.5, cursor: "pointer" }}>
                بازگشت به ورود
              </button>
            </div>
          )}

          {authMode === "forgot" && forgotStep === 2 && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <p style={{ fontSize: 12.5, color: COLORS.textDim, lineHeight: 1.8, marginBottom: 4, display: "flex", gap: 8 }}>
                <KeyRound size={16} style={{ flexShrink: 0, marginTop: 2 }} />
                کدی که دریافت کردی رو وارد کن و رمز جدیدت رو انتخاب کن.
              </p>
              <input inputMode="numeric" placeholder="کد ۶ رقمی" value={forgotForm.code} onChange={(e) => setForgotForm({ ...forgotForm, code: e.target.value })} style={{ ...inputStyle, textAlign: "center", letterSpacing: 4, direction: "ltr" }} />
              <input type="password" placeholder="رمز عبور جدید" value={forgotForm.newPassword} onChange={(e) => setForgotForm({ ...forgotForm, newPassword: e.target.value })} style={inputStyle} />
              <input type="password" placeholder="تکرار رمز عبور جدید" value={forgotForm.confirm} onChange={(e) => setForgotForm({ ...forgotForm, confirm: e.target.value })} onKeyDown={(e) => e.key === "Enter" && submitReset()} style={inputStyle} />
              <p style={{ fontSize: 11.5, color: COLORS.textDim, display: "flex", gap: 6 }}>
                <Lock size={13} style={{ flexShrink: 0, marginTop: 2 }} /> نمی‌تونی از رمزهای عبور قبلی‌ت دوباره استفاده کنی.
              </p>
              {authError && <p style={{ color: "#ff6b6b", fontSize: 13 }}>{authError}</p>}
              <button type="button" onClick={submitReset} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>
                تغییر رمز عبور
              </button>
              <button type="button" onClick={() => setForgotStep(1)} style={{ background: "none", border: "none", color: COLORS.textDim, fontSize: 12.5, cursor: "pointer" }}>
                کد رو دریافت نکردی؟ دوباره امتحان کن
              </button>
            </div>
          )}
        </Modal>
      )}

      {/* ---------- مودال افزودن محصول ---------- */}
      {showAddProduct && (
        <AddProductModal onClose={() => setShowAddProduct(false)} onAdd={(newProduct) => {
          setProducts((prev) => [{ ...newProduct, id: "p" + Date.now() }, ...prev]);
          setShowAddProduct(false);
          showToast("محصول جدید اضافه شد ✅");
        }} />
      )}

      {/* ---------- مودال ویرایش محصول (شامل تخفیف مستقیم) ---------- */}
      {editingProduct && (
        <AddProductModal
          product={editingProduct}
          onClose={() => setEditingProduct(null)}
          onAdd={(updated) => {
            editProduct(editingProduct.id, updated);
            setEditingProduct(null);
          }}
        />
      )}

      {/* ---------- مودال پرداخت ---------- */}
      {showCheckout && (
        <CheckoutModal
          subtotal={cartSubtotal}
          total={cartTotal}
          appliedCode={appliedCode}
          codeDiscountAmount={codeDiscountAmount}
          onApplyCode={applyDiscountCode}
          onRemoveCode={removeAppliedCode}
          onClose={() => setShowCheckout(false)}
          onPay={placeOrder}
        />
      )}

      {/* ---------- مودال پنل تخفیف (ادمین) ---------- */}
      {showDiscounts && (
        <DiscountPanelModal
          codes={discountCodes}
          onClose={() => setShowDiscounts(false)}
          onAdd={addDiscountCode}
          onUpdate={updateDiscountCode}
          onDelete={deleteDiscountCode}
        />
      )}

      {/* ---------- مودال کیف پول (کاربر) ---------- */}
      {showWallet && (
        <WalletModal
          balance={myWalletBalance}
          onClose={() => setShowWallet(false)}
          onSubmit={requestWalletCharge}
        />
      )}

      {/* ---------- مودال درخواست‌های شارژ کیف پول + شارژ دستی (ادمین) ---------- */}
      {showWalletRequests && (
        <WalletRequestsModal
          users={users}
          requests={walletRequests}
          onClose={() => setShowWalletRequests(false)}
          onConfirmRequest={confirmWalletRequest}
          onManualCharge={adminChargeWallet}
        />
      )}

      {/* ---------- مودال خرید مشتری (ادمین) ---------- */}
      {showOrders && (
        <Modal title="خرید مشتری" onClose={() => setShowOrders(false)}>
          {orders.length === 0 ? (
            <p style={{ color: COLORS.textDim, textAlign: "center", padding: 20 }}>هنوز سفارشی ثبت نشده.</p>
          ) : (
            <div className="scrollbar-thin" style={{ display: "flex", flexDirection: "column", gap: 18, maxHeight: 460, overflowY: "auto" }}>
              {Object.values(
                orders.reduce((groups, o) => {
                  const key = o.buyerEmail;
                  if (!groups[key]) groups[key] = { buyerName: o.buyerName, buyerEmail: o.buyerEmail, orders: [] };
                  groups[key].orders.push(o);
                  return groups;
                }, {})
              ).map((group) => (
                <div key={group.buyerEmail}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8, paddingBottom: 6, borderBottom: `1px solid ${COLORS.line}` }}>
                    <strong style={{ fontSize: 14 }}>{group.buyerName}</strong>
                    <span style={{ color: COLORS.textDim, fontSize: 11 }}>{group.buyerEmail}</span>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {group.orders.map((o) => (
                      <div key={o.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12, fontSize: 13 }}>
                        {o.minecraftName && (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, color: COLORS.purple, fontSize: 12.5, fontWeight: 700 }}>
                            <UserIcon size={13} /> اکانت ماین‌کرافت: {o.minecraftName}
                          </div>
                        )}
                        <p style={{ color: COLORS.textDim, fontSize: 12, marginBottom: 6 }}>
                          {o.items.map((it) => `${it.name} ×${it.qty}`).join("، ")}
                        </p>
                        {o.receiptImage && (
                          <a href={o.receiptImage} target="_blank" rel="noreferrer" style={{ display: "block", marginBottom: 8 }}>
                            <img src={o.receiptImage} alt="رسید پرداخت" style={{ width: "100%", maxHeight: 160, objectFit: "cover", borderRadius: 8, border: `1px solid ${COLORS.line}` }} />
                          </a>
                        )}
                        {o.discountCode && (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, color: COLORS.gold, fontSize: 11.5 }}>
                            <Ticket size={12} /> کد «{o.discountCode}» — {fmt(o.discountAmount)} تومان تخفیف
                          </div>
                        )}
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span style={{ fontWeight: 700 }}>{fmt(o.total)} تومان</span>
                          <span style={{ color: o.status.includes("انتظار") ? COLORS.gold : "#7ee081", fontSize: 12 }}>{o.status}</span>
                        </div>
                        {o.status === "در انتظار تأیید واریز" && (
                          <button onClick={() => confirmOrder(o.id)} style={{ marginTop: 8, width: "100%", background: COLORS.surface2, border: `1px solid ${COLORS.purple}`, color: COLORS.text, padding: "7px", borderRadius: 8, cursor: "pointer", fontSize: 12.5 }}>
                            تأیید واریز
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* ---------- Toast ---------- */}
      {toast && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", zIndex: 200, background: COLORS.surface2, border: `1px solid ${COLORS.purple}`, color: COLORS.text, padding: "12px 22px", borderRadius: 12, fontSize: 13.5, display: "flex", alignItems: "center", gap: 8, boxShadow: "0 10px 30px rgba(0,0,0,0.4)", maxWidth: "90vw", textAlign: "center" }}>
          <Check size={15} color={COLORS.purple} /> {toast}
        </div>
      )}
    </div>
  );
}

/* ---------- کامپوننت‌های کمکی ---------- */

function SectionHeading({ eyebrow, title }) {
  const [ref, visible] = useReveal();
  return (
    <div ref={ref} className={`reveal ${visible ? "in" : ""}`} style={{ textAlign: "center" }}>
      <div className="pixel" style={{ fontSize: 11, color: COLORS.pink, marginBottom: 12, letterSpacing: 1 }}>{eyebrow}</div>
      <h2 style={{ fontSize: "clamp(24px,4vw,34px)", fontWeight: 800 }}>{title}</h2>
    </div>
  );
}

function FeatureCard({ f, i }) {
  const [ref, visible] = useReveal();
  return (
    <div ref={ref} className={`reveal ${visible ? "in" : ""}`} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 18, padding: 26, transitionDelay: `${i * 0.1}s` }}>
      <div className="pixel" style={{ fontSize: 22, color: COLORS.pink, marginBottom: 14 }}>{f.n}</div>
      <div style={{ marginBottom: 12 }}>{f.icon}</div>
      <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>{f.title}</h3>
      <p style={{ color: COLORS.textDim, fontSize: 14, lineHeight: 1.8 }}>{f.desc}</p>
    </div>
  );
}

function ProductCard({ p, i, isAdmin, onDelete, onAdd, onEdit }) {
  const [ref, visible] = useReveal();
  const rarity = RARITY[p.rarity] || RARITY.common;
  const effectivePrice = getEffectivePrice(p);
  const hasDiscount = effectivePrice < p.price;
  return (
    <div ref={ref} className={`reveal card-hover ${visible ? "in" : ""}`} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 18, padding: 18, position: "relative", transitionDelay: `${(i % 4) * 0.08}s` }}>
      {isAdmin && (
        <div style={{ position: "absolute", top: 12, left: 12, display: "flex", gap: 6, zIndex: 2 }}>
          <button onClick={() => onEdit(p)} style={{ background: "rgba(0,0,0,0.4)", border: "none", borderRadius: 8, padding: 6, cursor: "pointer", color: COLORS.purple }}>
            <Pencil size={14} />
          </button>
          <button onClick={() => onDelete(p.id)} style={{ background: "rgba(0,0,0,0.4)", border: "none", borderRadius: 8, padding: 6, cursor: "pointer", color: "#ff6b6b" }}>
            <Trash2 size={14} />
          </button>
        </div>
      )}
      {hasDiscount && (
        <div style={{ position: "absolute", top: 12, right: 12, zIndex: 2, background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, color: "white", fontSize: 10.5, fontWeight: 800, padding: "4px 8px", borderRadius: 999, display: "flex", alignItems: "center", gap: 4 }}>
          <Tag size={10} />
          {p.discountType === "percent" ? `٪${p.discountValue}` : `${fmt(p.discountValue)} ت`} تخفیف
        </div>
      )}
      <div style={{ fontSize: 11, fontWeight: 700, color: rarity.color, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ width: 7, height: 7, borderRadius: 999, background: rarity.color, display: "inline-block" }} />{rarity.label}
      </div>
      <div style={{ height: 110, borderRadius: 12, background: `radial-gradient(circle, ${COLORS.surface2}, ${COLORS.bgSoft})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 46, marginBottom: 14, overflow: "hidden" }}>
        {p.image ? <img src={p.image} alt={p.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : p.icon}
      </div>
      <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 6, minHeight: 40 }}>{p.name}</h3>
      <p style={{ fontSize: 12.5, color: COLORS.textDim, lineHeight: 1.7, marginBottom: 14, minHeight: 42 }}>{p.desc}</p>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", gap: 6 }}>
          {hasDiscount && <span style={{ fontSize: 11.5, color: COLORS.textDim, textDecoration: "line-through", fontWeight: 400 }}>{fmt(p.price)}</span>}
          {fmt(effectivePrice)} <span style={{ fontSize: 11, color: COLORS.textDim, fontWeight: 400 }}>تومان</span>
        </span>
        <button onClick={() => onAdd(p)} style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "8px 10px", borderRadius: 9, cursor: "pointer", display: "flex", alignItems: "center" }}><Plus size={16} /></button>
      </div>
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 300, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)" }} />
      <div className="scrollbar-thin" style={{ position: "relative", background: COLORS.bgSoft, border: `1px solid ${COLORS.line}`, borderRadius: 18, padding: 26, width: "100%", maxWidth: 400, maxHeight: "88vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <h3 style={{ fontSize: 17, fontWeight: 700 }}>{title}</h3>
          <button onClick={onClose} style={iconBtnStyle}><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function AddProductModal({ onClose, onAdd, product }) {
  const isEdit = !!product;
  const [form, setForm] = useState(
    product
      ? {
          name: product.name,
          price: String(product.price),
          category: product.category,
          rarity: product.rarity,
          desc: product.desc,
          image: product.image || null,
          discountType: product.discountType || "none",
          discountValue: product.discountValue ? String(product.discountValue) : "",
        }
      : { name: "", price: "", category: "weapon", rarity: "common", desc: "", image: null, discountType: "none", discountValue: "" }
  );
  const fileRef = useRef(null);

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, image: reader.result }));
    reader.readAsDataURL(file);
  };

  const effectivePreview = (() => {
    const price = Number(form.price) || 0;
    const value = Number(form.discountValue) || 0;
    if (form.discountType === "none" || !value) return price;
    if (form.discountType === "percent") return Math.max(0, Math.round(price - (price * value) / 100));
    return Math.max(0, Math.round(price - value));
  })();

  const submit = () => {
    if (!form.name || !form.price) return;
    if (form.discountType === "percent" && Number(form.discountValue) > 100) return;
    onAdd({
      ...form,
      price: Number(form.price),
      icon: product?.icon || "📦",
      discountType: form.discountType,
      discountValue: form.discountType === "none" ? 0 : Number(form.discountValue) || 0,
    });
  };

  return (
    <Modal title={isEdit ? "ویرایش محصول" : "افزودن محصول به فروش"} onClose={onClose}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div onClick={() => fileRef.current?.click()} style={{ height: 110, borderRadius: 12, border: `1px dashed ${COLORS.line}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: "pointer", color: COLORS.textDim, fontSize: 13, overflow: "hidden", background: COLORS.surface }}>
          {form.image ? <img src={form.image} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <><Upload size={20} style={{ marginBottom: 6 }} /> آپلود عکس محصول</>}
        </div>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
        <input placeholder="نام محصول" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} style={inputStyle} />
        <input placeholder="قیمت (تومان)" type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} style={inputStyle} />
        <textarea placeholder="توضیحات کوتاه" value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} style={{ ...inputStyle, minHeight: 70, resize: "vertical" }} />
        <div style={{ display: "flex", gap: 10 }}>
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} style={{ ...inputStyle, flex: 1 }}>
            {CATEGORIES.filter((c) => c.id !== "all").map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
          <select value={form.rarity} onChange={(e) => setForm({ ...form, rarity: e.target.value })} style={{ ...inputStyle, flex: 1 }}>
            {Object.entries(RARITY).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>

        <div style={{ border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12, background: COLORS.surface }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: COLORS.textDim, marginBottom: 10 }}>
            <Tag size={14} color={COLORS.purple} /> تخفیف مستقیم روی این محصول (اختیاری)
          </div>
          <div style={{ display: "flex", gap: 10, marginBottom: form.discountType !== "none" ? 10 : 0 }}>
            <select value={form.discountType} onChange={(e) => setForm({ ...form, discountType: e.target.value })} style={{ ...inputStyle, flex: 1 }}>
              <option value="none">بدون تخفیف</option>
              <option value="percent">درصدی (٪)</option>
              <option value="fixed">مبلغ ثابت (تومان)</option>
            </select>
            {form.discountType !== "none" && (
              <input
                placeholder={form.discountType === "percent" ? "مثلاً ۲۰" : "مثلاً ۵۰۰۰۰"}
                type="number"
                value={form.discountValue}
                onChange={(e) => setForm({ ...form, discountValue: e.target.value })}
                style={{ ...inputStyle, flex: 1 }}
              />
            )}
          </div>
          {form.discountType !== "none" && form.price && (
            <div style={{ fontSize: 12, color: COLORS.textDim, display: "flex", gap: 8, alignItems: "center" }}>
              قیمت نهایی: <span style={{ textDecoration: "line-through" }}>{fmt(Number(form.price))}</span>
              <span style={{ color: COLORS.gold, fontWeight: 700 }}>{fmt(effectivePreview)} تومان</span>
            </div>
          )}
        </div>

        <button type="button" onClick={submit} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "pointer", marginTop: 6 }}>
          {isEdit ? "ذخیره تغییرات" : "افزودن به فروشگاه"}
        </button>
      </div>
    </Modal>
  );
}

function CheckoutModal({ subtotal, total, appliedCode, codeDiscountAmount, onApplyCode, onRemoveCode, onClose, onPay }) {
  const [tab, setTab] = useState("card2card");
  const [copied, setCopied] = useState(false);
  const [receiptImage, setReceiptImage] = useState(null);
  const [codeInput, setCodeInput] = useState("");
  const fileRef = useRef(null);

  const copyCard = async () => {
    try {
      await navigator.clipboard.writeText(CARD_NUMBER);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch (e) {}
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setReceiptImage(reader.result);
    reader.readAsDataURL(file);
  };

  return (
    <Modal title="پرداخت" onClose={onClose}>
      <div style={{ display: "flex", gap: 8, marginBottom: 18, background: COLORS.surface, padding: 4, borderRadius: 10 }}>
        <button onClick={() => setTab("card2card")} style={{ flex: 1, padding: "8px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 12.5, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: tab === "card2card" ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : "transparent", color: tab === "card2card" ? "white" : COLORS.textDim }}>
          <Wallet size={14} /> کارت به کارت
        </button>
        <button onClick={() => setTab("gateway")} style={{ flex: 1, padding: "8px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 12.5, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, background: tab === "gateway" ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : "transparent", color: tab === "gateway" ? "white" : COLORS.textDim }}>
          <CreditCard size={14} /> درگاه اینترنتی
        </button>
      </div>

      <div style={{ textAlign: "center", marginBottom: 14, fontSize: 14, color: COLORS.textDim }}>
        {codeDiscountAmount > 0 && (
          <div style={{ textDecoration: "line-through", fontSize: 12.5, marginBottom: 2 }}>{fmt(subtotal)} تومان</div>
        )}
        مبلغ قابل پرداخت: <span style={{ color: COLORS.text, fontWeight: 800, fontSize: 17 }}>{fmt(total)} تومان</span>
      </div>

      <div style={{ marginBottom: 18 }}>
        {appliedCode ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(126,224,129,0.1)", border: "1px solid rgba(126,224,129,0.35)", borderRadius: 10, padding: "10px 14px" }}>
            <span style={{ fontSize: 12.5, color: "#7ee081", display: "flex", alignItems: "center", gap: 6 }}>
              <Ticket size={14} /> کد «{appliedCode.code}» اعمال شد ({fmt(codeDiscountAmount)} تومان تخفیف)
            </span>
            <button onClick={onRemoveCode} style={{ background: "none", border: "none", color: "#ff6b6b", cursor: "pointer" }}><X size={14} /></button>
          </div>
        ) : (
          <div style={{ display: "flex", gap: 8 }}>
            <input
              placeholder="کد تخفیف داری؟"
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && (onApplyCode(codeInput), setCodeInput(""))}
              style={{ ...inputStyle, flex: 1, direction: "ltr", textAlign: "left" }}
            />
            <button
              onClick={() => { onApplyCode(codeInput); setCodeInput(""); }}
              style={{ background: COLORS.surface2, border: `1px solid ${COLORS.purple}`, color: COLORS.text, padding: "0 16px", borderRadius: 10, cursor: "pointer", fontSize: 13, fontWeight: 600 }}
            >
              اعمال
            </button>
          </div>
        )}
      </div>

      {tab === "card2card" ? (
        <div>
          <div style={{ background: `linear-gradient(135deg, ${COLORS.purpleDeep}, ${COLORS.pink})`, borderRadius: 14, padding: 20, marginBottom: 16, color: "white" }}>
            <div style={{ fontSize: 11, opacity: 0.8, marginBottom: 10 }}>شماره کارت مقصد</div>
            <div style={{ fontSize: 19, fontWeight: 800, letterSpacing: 1, direction: "ltr", textAlign: "left", marginBottom: 14 }}>{fmtCard(CARD_NUMBER)}</div>
            <button onClick={copyCard} style={{ background: "rgba(255,255,255,0.18)", border: "none", color: "white", padding: "7px 14px", borderRadius: 8, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
              <Copy size={13} /> {copied ? "کپی شد" : "کپی شماره کارت"}
            </button>
          </div>
          <p style={{ fontSize: 12.5, color: COLORS.textDim, lineHeight: 1.9, marginBottom: 10 }}>
            مبلغ بالا رو به شماره کارت واریز کن، بعد عکس رسید واریز رو آپلود کن. بدون عکس رسید، امکان ثبت سفارش نیست.
          </p>

          <div
            onClick={() => fileRef.current?.click()}
            style={{
              height: receiptImage ? 160 : 110, borderRadius: 12,
              border: `1px dashed ${receiptImage ? COLORS.purple : COLORS.line}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              cursor: "pointer", color: COLORS.textDim, fontSize: 13, overflow: "hidden",
              background: COLORS.surface, marginBottom: 16,
            }}
          >
            {receiptImage ? (
              <img src={receiptImage} alt="رسید پرداخت" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            ) : (
              <><Upload size={20} style={{ marginBottom: 6 }} /> آپلود عکس رسید پرداخت</>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
          {receiptImage && (
            <button
              onClick={() => setReceiptImage(null)}
              style={{ background: "none", border: "none", color: "#ff6b6b", fontSize: 12, cursor: "pointer", marginBottom: 12, display: "flex", alignItems: "center", gap: 6 }}
            >
              <Trash2 size={13} /> حذف عکس و آپلود دوباره
            </button>
          )}

          <button
            onClick={() => onPay("card2card", receiptImage)}
            disabled={!receiptImage}
            className="btn-primary"
            style={{
              width: "100%",
              background: receiptImage ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : COLORS.surface2,
              border: "none", color: receiptImage ? "white" : COLORS.textDim, padding: "12px", borderRadius: 10,
              fontWeight: 700, cursor: receiptImage ? "pointer" : "not-allowed",
            }}
          >
            پرداخت را انجام دادم
          </button>
          {!receiptImage && (
            <p style={{ fontSize: 11.5, color: COLORS.textDim, textAlign: "center", marginTop: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
              <ImageOff size={13} /> تا وقتی عکس رسید رو آپلود نکنی، این دکمه فعال نمی‌شه
            </p>
          )}
        </div>
      ) : (
        <div>
          <div style={{ background: "rgba(255,107,107,0.1)", border: "1px solid rgba(255,107,107,0.35)", borderRadius: 12, padding: 16, marginBottom: 16 }}>
            <p style={{ fontSize: 12.5, color: "#ff9d9d", lineHeight: 1.9, margin: 0 }}>
              پرداخت از طریق درگاه اینترنتی فعلاً <strong>غیرفعاله</strong>. فعلاً فقط از روش «کارت به کارت» استفاده کن.
            </p>
          </div>
          <button disabled className="btn-primary" style={{ width: "100%", background: COLORS.surface2, border: "none", color: COLORS.textDim, padding: "12px", borderRadius: 10, fontWeight: 700, cursor: "not-allowed" }}>
            غیرفعال
          </button>
        </div>
      )}
    </Modal>
  );
}

function WalletModal({ balance, onClose, onSubmit }) {
  const [step, setStep] = useState(1); // 1: مبلغ | 2: پرداخت و رسید
  const [amount, setAmount] = useState("");
  const [receiptImage, setReceiptImage] = useState(null);
  const [copied, setCopied] = useState(false);
  const fileRef = useRef(null);

  const numAmount = Number(amount) || 0;

  const goToPayment = () => {
    if (!numAmount || numAmount <= 0) return;
    setStep(2);
  };

  const copyCard = async () => {
    try {
      await navigator.clipboard.writeText(CARD_NUMBER);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch (e) {}
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setReceiptImage(reader.result);
    reader.readAsDataURL(file);
  };

  return (
    <Modal title="کیف پول" onClose={onClose}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "rgba(155,92,255,0.08)", border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 14, marginBottom: 18 }}>
        <span style={{ fontSize: 13, color: COLORS.textDim, display: "flex", alignItems: "center", gap: 6 }}><Wallet size={15} color={COLORS.purple} /> موجودی فعلی</span>
        <span style={{ fontSize: 16, fontWeight: 800, color: COLORS.gold }}>{fmt(balance)} تومان</span>
      </div>

      {step === 1 ? (
        <div>
          <label style={{ fontSize: 12.5, color: COLORS.textDim, display: "block", marginBottom: 8 }}>مبلغ شارژ (تومان)</label>
          <input
            placeholder="مثلاً: ۱۰۰۰۰۰"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && goToPayment()}
            style={{ ...inputStyle, marginBottom: 16 }}
          />
          <button
            onClick={goToPayment}
            disabled={!numAmount || numAmount <= 0}
            className="btn-primary"
            style={{
              width: "100%",
              background: numAmount > 0 ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : COLORS.surface2,
              border: "none", color: numAmount > 0 ? "white" : COLORS.textDim, padding: "12px", borderRadius: 10,
              fontWeight: 700, cursor: numAmount > 0 ? "pointer" : "not-allowed",
            }}
          >
            برو به صفحه پرداخت
          </button>
        </div>
      ) : (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, fontSize: 12.5, color: COLORS.textDim, cursor: "pointer" }} onClick={() => setStep(1)}>
            ‹ ویرایش مبلغ ({fmt(numAmount)} تومان)
          </div>

          <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: COLORS.textDim, marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
              <CreditCard size={14} color={COLORS.purple} /> شماره کارت جهت واریز
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontFamily: "monospace", fontSize: 15, letterSpacing: 1, direction: "ltr" }}>{fmtCard(CARD_NUMBER)}</span>
              <button onClick={copyCard} style={{ background: "none", border: "none", color: copied ? "#7ee081" : COLORS.purple, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 12 }}>
                {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "کپی شد" : "کپی"}
              </button>
            </div>
          </div>

          <p style={{ fontSize: 12.5, color: COLORS.textDim, lineHeight: 1.9, marginBottom: 14 }}>
            مبلغ <strong style={{ color: COLORS.gold }}>{fmt(numAmount)} تومان</strong> رو کارت‌به‌کارت کن، بعد عکس رسیدش رو آپلود کن.
          </p>

          <div
            onClick={() => fileRef.current?.click()}
            style={{
              height: receiptImage ? 160 : 110, borderRadius: 12,
              border: `1px dashed ${receiptImage ? COLORS.purple : COLORS.line}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              cursor: "pointer", color: COLORS.textDim, fontSize: 13, overflow: "hidden",
              background: COLORS.surface, marginBottom: 16,
            }}
          >
            {receiptImage ? (
              <img src={receiptImage} alt="رسید واریز" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            ) : (
              <><Upload size={20} style={{ marginBottom: 6 }} /> آپلود عکس رسید واریز</>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
          {receiptImage && (
            <button
              onClick={() => setReceiptImage(null)}
              style={{ background: "none", border: "none", color: "#ff6b6b", fontSize: 12, cursor: "pointer", marginBottom: 12, display: "flex", alignItems: "center", gap: 6 }}
            >
              <Trash2 size={13} /> حذف عکس و آپلود دوباره
            </button>
          )}

          <button
            onClick={() => onSubmit(numAmount, receiptImage)}
            disabled={!receiptImage}
            className="btn-primary"
            style={{
              width: "100%",
              background: receiptImage ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : COLORS.surface2,
              border: "none", color: receiptImage ? "white" : COLORS.textDim, padding: "12px", borderRadius: 10,
              fontWeight: 700, cursor: receiptImage ? "pointer" : "not-allowed",
            }}
          >
            ثبت درخواست شارژ
          </button>
          {!receiptImage && (
            <p style={{ fontSize: 11.5, color: COLORS.textDim, textAlign: "center", marginTop: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
              <ImageOff size={13} /> تا وقتی عکس رسید رو آپلود نکنی، این دکمه فعال نمی‌شه
            </p>
          )}
        </div>
      )}
    </Modal>
  );
}

function WalletRequestsModal({ users, requests, onClose, onConfirmRequest, onManualCharge }) {
  const [targetEmail, setTargetEmail] = useState("");
  const [amount, setAmount] = useState("");

  const chargeableUsers = users.filter((u) => u.email !== ADMIN_EMAIL);

  const submitManual = () => {
    const ok = onManualCharge(targetEmail, amount);
    if (ok) setAmount("");
  };

  return (
    <Modal title="کیف پول کاربران" onClose={onClose}>
      <div style={{ border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 14, background: COLORS.surface, marginBottom: 18 }}>
        <div style={{ fontSize: 12.5, color: COLORS.textDim, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
          <Wallet size={14} color={COLORS.purple} /> شارژ دستی کیف پول (بدون نیاز به رسید)
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <select value={targetEmail} onChange={(e) => setTargetEmail(e.target.value)} style={inputStyle}>
            <option value="">— انتخاب کاربر —</option>
            {chargeableUsers.map((u) => (
              <option key={u.email} value={u.email}>{u.name} ({u.email}) — موجودی: {fmt(u.wallet || 0)}</option>
            ))}
          </select>
          <input
            placeholder="مبلغ (تومان) — برای کسر، منفی وارد کن مثلاً -20000"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            style={inputStyle}
          />
          <button
            type="button"
            onClick={submitManual}
            disabled={!targetEmail || !amount}
            className="btn-primary"
            style={{
              background: targetEmail && amount ? `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})` : COLORS.surface2,
              border: "none", color: targetEmail && amount ? "white" : COLORS.textDim, padding: "11px", borderRadius: 10,
              fontWeight: 700, cursor: targetEmail && amount ? "pointer" : "not-allowed",
            }}
          >
            اعمال شارژ
          </button>
        </div>
      </div>

      <div style={{ fontSize: 12.5, color: COLORS.textDim, marginBottom: 10 }}>درخواست‌های شارژ کاربران ({requests.length})</div>

      {requests.length === 0 ? (
        <p style={{ color: COLORS.textDim, textAlign: "center", padding: 16, fontSize: 13 }}>هنوز درخواست شارژی ثبت نشده.</p>
      ) : (
        <div className="scrollbar-thin" style={{ display: "flex", flexDirection: "column", gap: 10, maxHeight: 380, overflowY: "auto" }}>
          {requests.map((w) => (
            <div key={w.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12, fontSize: 13 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <strong style={{ fontSize: 13.5 }}>{w.buyerName}</strong>
                <span style={{ color: COLORS.textDim, fontSize: 11 }}>{w.buyerEmail}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, color: COLORS.gold, fontWeight: 700, fontSize: 14 }}>
                <Wallet size={14} /> مبلغ درخواستی: {fmt(w.amount)} تومان
              </div>
              {w.receiptImage && (
                <a href={w.receiptImage} target="_blank" rel="noreferrer" style={{ display: "block", marginBottom: 8 }}>
                  <img src={w.receiptImage} alt="رسید واریز" style={{ width: "100%", maxHeight: 160, objectFit: "cover", borderRadius: 8, border: `1px solid ${COLORS.line}` }} />
                </a>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: w.status.includes("انتظار") ? COLORS.gold : "#7ee081", fontSize: 12 }}>{w.status}</span>
                {w.status === "در انتظار تأیید واریز" && (
                  <button onClick={() => onConfirmRequest(w.id)} style={{ background: COLORS.surface2, border: `1px solid ${COLORS.purple}`, color: COLORS.text, padding: "7px 14px", borderRadius: 8, cursor: "pointer", fontSize: 12.5 }}>
                    تأیید و شارژ
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

function DiscountPanelModal({ codes, onClose, onAdd, onUpdate, onDelete }) {
  const [form, setForm] = useState({ code: "", type: "percent", value: "" });
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ type: "percent", value: "" });

  const submit = () => {
    const ok = onAdd(form);
    if (ok) setForm({ code: "", type: "percent", value: "" });
  };

  const startEdit = (d) => {
    setEditingId(d.id);
    setEditForm({ type: d.type, value: String(d.value) });
  };

  const saveEdit = (id) => {
    const value = Number(editForm.value);
    if (!value || value <= 0) return;
    if (editForm.type === "percent" && value > 100) return;
    onUpdate(id, { type: editForm.type, value });
    setEditingId(null);
  };

  return (
    <Modal title="پنل تخفیف" onClose={onClose}>
      <div style={{ border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 14, background: COLORS.surface, marginBottom: 18 }}>
        <div style={{ fontSize: 12.5, color: COLORS.textDim, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
          <Ticket size={14} color={COLORS.purple} /> ساخت کد تخفیف جدید
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <input
            placeholder="کد (مثلاً OFF20)"
            value={form.code}
            onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
            style={{ ...inputStyle, direction: "ltr", textAlign: "left" }}
          />
          <div style={{ display: "flex", gap: 10 }}>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} style={{ ...inputStyle, flex: 1 }}>
              <option value="percent">درصدی (٪)</option>
              <option value="fixed">مبلغ ثابت (تومان)</option>
            </select>
            <input
              placeholder={form.type === "percent" ? "مثلاً ۱۵" : "مثلاً ۳۰۰۰۰"}
              type="number"
              value={form.value}
              onChange={(e) => setForm({ ...form, value: e.target.value })}
              style={{ ...inputStyle, flex: 1 }}
            />
          </div>
          <button type="button" onClick={submit} className="btn-primary" style={{ background: `linear-gradient(90deg, ${COLORS.purple}, ${COLORS.pink})`, border: "none", color: "white", padding: "11px", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>
            ساخت کد تخفیف
          </button>
        </div>
      </div>

      <div style={{ fontSize: 12.5, color: COLORS.textDim, marginBottom: 10 }}>کدهای موجود ({codes.length})</div>

      {codes.length === 0 ? (
        <p style={{ color: COLORS.textDim, textAlign: "center", padding: 16, fontSize: 13 }}>هنوز کد تخفیفی نساختی.</p>
      ) : (
        <div className="scrollbar-thin" style={{ display: "flex", flexDirection: "column", gap: 10, maxHeight: 320, overflowY: "auto" }}>
          {codes.map((d) => (
            <div key={d.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: editingId === d.id ? 10 : 0 }}>
                <span style={{ fontWeight: 800, fontSize: 14, direction: "ltr" }}>{d.code}</span>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <button
                    onClick={() => onUpdate(d.id, { active: !d.active })}
                    style={{
                      fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 999, border: "none", cursor: "pointer",
                      background: d.active ? "rgba(126,224,129,0.15)" : "rgba(255,107,107,0.15)",
                      color: d.active ? "#7ee081" : "#ff6b6b",
                    }}
                  >
                    {d.active ? "فعال" : "غیرفعال"}
                  </button>
                  <button onClick={() => startEdit(d)} style={{ background: "none", border: "none", color: COLORS.purple, cursor: "pointer" }}><Pencil size={14} /></button>
                  <button onClick={() => onDelete(d.id)} style={{ background: "none", border: "none", color: "#ff6b6b", cursor: "pointer" }}><Trash2 size={14} /></button>
                </div>
              </div>

              {editingId === d.id ? (
                <div style={{ display: "flex", gap: 8 }}>
                  <select value={editForm.type} onChange={(e) => setEditForm({ ...editForm, type: e.target.value })} style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }}>
                    <option value="percent">درصدی (٪)</option>
                    <option value="fixed">مبلغ ثابت (تومان)</option>
                  </select>
                  <input
                    type="number"
                    value={editForm.value}
                    onChange={(e) => setEditForm({ ...editForm, value: e.target.value })}
                    style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }}
                  />
                  <button onClick={() => saveEdit(d.id)} style={{ background: COLORS.purple, border: "none", color: "white", borderRadius: 8, padding: "0 12px", cursor: "pointer" }}>
                    <Check size={14} />
                  </button>
                </div>
              ) : (
                <p style={{ fontSize: 12.5, color: COLORS.textDim, margin: 0 }}>
                  {d.type === "percent" ? `٪${d.value} تخفیف` : `${fmt(d.value)} تومان تخفیف`}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

const iconBtnStyle = { background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: 8, color: COLORS.text, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" };
const qtyBtnStyle = { background: COLORS.surface2, border: `1px solid ${COLORS.line}`, borderRadius: 6, width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: COLORS.text };
const inputStyle = { background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: "11px 14px", color: COLORS.text, fontSize: 13.5, outline: "none", width: "100%" };
const dotBadge = { position: "absolute", top: -6, left: -6, background: COLORS.pink, color: "white", fontSize: 11, borderRadius: 999, width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 };
